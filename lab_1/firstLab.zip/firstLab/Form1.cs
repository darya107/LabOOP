﻿using firstLab.Shapes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace firstLab
{
    public partial class Form1 : Form
    {
        ShapeList list = new ShapeList();
        public Form1()
        {
            InitializeComponent();

            this.Width = 800;
            this.Height = 600;

            list.Add(new LineShape(10, 10, 200, 100, Color.Red));
            list.Add(new RectangleShape(50, 150, 120, 80, Color.Blue));
            list.Add(new EllipseShape(250, 150, 150, 80, Color.Green));
            list.Add(new CircleShape(450, 150, 50, Color.Purple));
            list.Add(new SquareShape(100, 300, 100, Color.Orange));
            list.Add(new TriangleShape(
                new Point(300, 300),
                new Point(400, 400),
                new Point(200, 400),
                Color.Brown));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            list.DrawAll(e.Graphics);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
